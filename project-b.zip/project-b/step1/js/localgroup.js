var mic;

class objects {
  constructor() {
    this.vx = random(-1, 2);
    this.vy = random(-0.2, 1);
    this.x = random(width);
    this.y = random(height);
    this.m = random(height / 0.8, height);
    this.c = random();
    this.w = random(10, 1);
  }
  draw(level) {
    fill(this.c, 0.3 + level, 0.5, 1 - level);
    ellipse(this.x, this.y, this.m * level);

    this.x += this.vx * (1 + level);
    this.y += this.vy * (1 + level);

    if (this.x > width || this.x < 0) {
      this.vx = -this.vx
    }
    if (this.y > height || this.y < 0) {
      this.vy = -this.vy
    }
  }
}
let nBalls = 50;
let balls = [];
function setup() {
  let canvas = createCanvas(500, 350);
  canvas.parent("p5-canvas-container");
  background(50);
  mic = new p5.AudioIn()

  mic.start();
  colorMode(RGB, 6);

  for (let i = 0; i < nBalls; i++) {
    balls.push(new objects());
  }
}

function draw() {
  background(0, 0.15);
  micLevel = mic.getLevel(100.9);
  for (let i = 0; i < nBalls; i++) {
    balls[i].draw(micLevel);
  }
  for (var x = 0; x < width; x += 5) {
    var noiseVal = noise((micLevel + x) * 200, micLevel * 100);
    stroke(noiseVal * 100);
    fill(2, 3, 5);
    stroke(random(7, 10), 127, 255, 127);

  }
}